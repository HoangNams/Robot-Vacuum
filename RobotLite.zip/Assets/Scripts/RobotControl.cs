using UnityEngine;
using UnityEngine.InputSystem;

public class RobotController : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float rotationSpeed = 180f;

    private Vector2 moveInput;

    void Update()
    {
        // Di chuyển
        transform.Translate(Vector3.right * moveInput.x * moveSpeed * Time.deltaTime);
        transform.Rotate(Vector3.back, moveInput.y * rotationSpeed * Time.deltaTime);
    }

    public void OnMove(InputAction.CallbackContext context)
    {
        moveInput = context.ReadValue<Vector2>();
    }
}
