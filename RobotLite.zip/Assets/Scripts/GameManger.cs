using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public Text winText;
    private int totalDusts;
    private int collectedDusts = 0;

    void Start()
    {
        winText.gameObject.SetActive(false);
        totalDusts = GameObject.FindGameObjectsWithTag("Dust").Length;
    }

    public void OnDustCollected()
    {
        collectedDusts++;
        if (collectedDusts >= totalDusts)
        {
            winText.gameObject.SetActive(true);
            winText.text = "You Win!";
        }
    }
}
